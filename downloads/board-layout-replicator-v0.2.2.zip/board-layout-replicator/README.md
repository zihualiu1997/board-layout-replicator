# 展板复刻 Skill · board-layout-replicator

把喜欢的参考展板拆成提示词，再用自己的建筑底图生成同类版式的完整展板。

**当前版本：v0.2.2 · 2026-10-20 · [MIT](LICENSE)**

## 工作方式

**参考展板 → 视觉分析与英文提示词 → 建筑底图＋提示词 → GPT Image 完整展板**

Skill 先拆解参考展板的内容、构图、视觉风格，并把关键布局写入英文提示词。生图阶段默认只传目标建筑底图，不再绑定参考展板。模型会根据版式补齐分析图、爆炸轴测、概念平剖面和辅助视角。

## 下载与安装

[下载 v0.2.2 安装包](https://github.com/zihualiu1997/board-layout-replicator/blob/main/downloads/board-layout-replicator-v0.2.2.zip)

解压后，将整个 `board-layout-replicator` 文件夹放到项目的 `.agents/skills/` 下：

```text
你的项目/
└── .agents/
    └── skills/
        └── board-layout-replicator/
            ├── SKILL.md
            ├── LICENSE
            ├── agents/openai.yaml
            └── references/generation-prompt.md
```

也可以直接复制本仓库的 `SKILL.md`、`LICENSE`、`agents/`、`references/` 到上述 Skill 文件夹。

运行环境需要能看图并调用 GPT Image。该 Skill 是指令与提示词，不附带模型服务或 API Key，无额外 Python 依赖。新安装后若会话未发现 Skill，请重新打开项目会话。

## 怎么用

上传一张参考展板和一张建筑底图，然后发送：

```text
使用 $board-layout-replicator。
第一张是参考展板，第二张是我的建筑底图。
先分析参考板，生成英文提示词，再只用底图和提示词生成完整展板。
```

只要提示词时追加：

```text
先不生图，只输出四部分拆解和最终英文提示词。
```

多组案例请说明配对，例如“商业底图配蓝色左栏展板；体育馆底图配顶部大图展板”。

## 输出

- 四部分参考分析：内容、构图、视觉与画风、最终生成提示词。
- 实际使用的英文提示词。
- 完整生成展板。
- 版式、建筑特征、小字与推演内容的检查记录。

## 已有验证

已完成黄昏商业、夜景体育馆两组实际生图，每组一次初始生成。分别测试了“贯通蓝色左栏＋右侧场景”和“顶部主图＋中部爆炸图”的布局。两组均按底图＋提示词生成。

生成的平剖面、结构和不可见内部空间是 AI 推演，适合探索排版与表达方向。实际测试中出现过屋顶、内部空间和小字的偏差，仍需人工复核。尚未验证所有版式的稳定性、跨模型效果或新会话自动发现，不将输出当作真实工程图纸。

## 文件

- [SKILL.md](SKILL.md)：完整运行规则。
- [提示词结构](references/generation-prompt.md)：可复用英文提示词模板。
- [更新记录](CHANGELOG.md)。

## 方法来源

zhl / airilab 的[展板复刻教程](https://www.xiaohongshu.com/explore/69f54efb000000003502bb4a)。v0.2.0 根据作者确认，采用“参考板提词，再由底图＋提示词直接生成完整展板”的运行逻辑。

## 许可

原创 Skill 指令、提示词和文档采用 [MIT License](LICENSE)。允许商业使用、修改、出售与再分发；分发副本或实质性部分时，须保留版权声明和许可文本，无需公开修改后的源码。

本版本仅更新许可及分发说明，Skill 的生成逻辑和参考资源保持不变。历史版本曾以 Unlicense 发布；既有授权不因本次变更撤回。旧安装包可从 Git 历史追溯，当前下载入口仅提供 MIT 版本。

本许可针对仓库内容，不代替所使用图像模型服务的条款，也不替使用者取得其自行上传素材的权利。
